﻿namespace AplicacionEscritorio
{
    partial class VerDetalle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbxArt = new System.Windows.Forms.PictureBox();
            this.lblId = new System.Windows.Forms.Label();
            this.lblMostrarId = new System.Windows.Forms.Label();
            this.lblMostrarCodigo = new System.Windows.Forms.Label();
            this.lblCodigo = new System.Windows.Forms.Label();
            this.lblMostrarDescripcion = new System.Windows.Forms.Label();
            this.lblDescripcion = new System.Windows.Forms.Label();
            this.lblMostrarNombre = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblMarca = new System.Windows.Forms.Label();
            this.lblCategoria = new System.Windows.Forms.Label();
            this.lblPrecio = new System.Windows.Forms.Label();
            this.lblMostrarMarca = new System.Windows.Forms.Label();
            this.lblMostrarCategoria = new System.Windows.Forms.Label();
            this.lblMostrarPrecio = new System.Windows.Forms.Label();
            this.btnCerrar = new System.Windows.Forms.Button();
            this.btnMin = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbxArt)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // pbxArt
            // 
            this.pbxArt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxArt.BackColor = System.Drawing.Color.DimGray;
            this.pbxArt.Location = new System.Drawing.Point(351, 68);
            this.pbxArt.Name = "pbxArt";
            this.pbxArt.Size = new System.Drawing.Size(279, 340);
            this.pbxArt.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxArt.TabIndex = 5;
            this.pbxArt.TabStop = false;
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.BackColor = System.Drawing.Color.Gray;
            this.lblId.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblId.Location = new System.Drawing.Point(109, 54);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(46, 26);
            this.lblId.TabIndex = 6;
            this.lblId.Text = "ID:";
            // 
            // lblMostrarId
            // 
            this.lblMostrarId.AutoSize = true;
            this.lblMostrarId.BackColor = System.Drawing.Color.DimGray;
            this.lblMostrarId.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostrarId.Location = new System.Drawing.Point(21, 57);
            this.lblMostrarId.MaximumSize = new System.Drawing.Size(300, 100);
            this.lblMostrarId.Name = "lblMostrarId";
            this.lblMostrarId.Size = new System.Drawing.Size(62, 26);
            this.lblMostrarId.TabIndex = 7;
            this.lblMostrarId.Text = "-----";
            // 
            // lblMostrarCodigo
            // 
            this.lblMostrarCodigo.AutoSize = true;
            this.lblMostrarCodigo.BackColor = System.Drawing.Color.DimGray;
            this.lblMostrarCodigo.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostrarCodigo.Location = new System.Drawing.Point(21, 88);
            this.lblMostrarCodigo.MaximumSize = new System.Drawing.Size(300, 100);
            this.lblMostrarCodigo.Name = "lblMostrarCodigo";
            this.lblMostrarCodigo.Size = new System.Drawing.Size(62, 26);
            this.lblMostrarCodigo.TabIndex = 9;
            this.lblMostrarCodigo.Text = "-----";
            // 
            // lblCodigo
            // 
            this.lblCodigo.AutoSize = true;
            this.lblCodigo.BackColor = System.Drawing.Color.Gray;
            this.lblCodigo.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodigo.Location = new System.Drawing.Point(60, 85);
            this.lblCodigo.Name = "lblCodigo";
            this.lblCodigo.Size = new System.Drawing.Size(95, 26);
            this.lblCodigo.TabIndex = 8;
            this.lblCodigo.Text = "Codigo:";
            // 
            // lblMostrarDescripcion
            // 
            this.lblMostrarDescripcion.AutoSize = true;
            this.lblMostrarDescripcion.BackColor = System.Drawing.Color.DimGray;
            this.lblMostrarDescripcion.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostrarDescripcion.Location = new System.Drawing.Point(21, 150);
            this.lblMostrarDescripcion.MaximumSize = new System.Drawing.Size(300, 100);
            this.lblMostrarDescripcion.Name = "lblMostrarDescripcion";
            this.lblMostrarDescripcion.Size = new System.Drawing.Size(62, 26);
            this.lblMostrarDescripcion.TabIndex = 11;
            this.lblMostrarDescripcion.Text = "-----";
            // 
            // lblDescripcion
            // 
            this.lblDescripcion.AutoSize = true;
            this.lblDescripcion.BackColor = System.Drawing.Color.Gray;
            this.lblDescripcion.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescripcion.Location = new System.Drawing.Point(11, 147);
            this.lblDescripcion.Name = "lblDescripcion";
            this.lblDescripcion.Size = new System.Drawing.Size(144, 26);
            this.lblDescripcion.TabIndex = 10;
            this.lblDescripcion.Text = "Descripcion:";
            // 
            // lblMostrarNombre
            // 
            this.lblMostrarNombre.AutoSize = true;
            this.lblMostrarNombre.BackColor = System.Drawing.Color.DimGray;
            this.lblMostrarNombre.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostrarNombre.Location = new System.Drawing.Point(21, 119);
            this.lblMostrarNombre.MaximumSize = new System.Drawing.Size(300, 100);
            this.lblMostrarNombre.Name = "lblMostrarNombre";
            this.lblMostrarNombre.Size = new System.Drawing.Size(62, 26);
            this.lblMostrarNombre.TabIndex = 13;
            this.lblMostrarNombre.Text = "-----";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.BackColor = System.Drawing.Color.Gray;
            this.lblNombre.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre.Location = new System.Drawing.Point(49, 116);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(106, 26);
            this.lblNombre.TabIndex = 12;
            this.lblNombre.Text = "Nombre:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.Controls.Add(this.btnCerrar);
            this.panel1.Controls.Add(this.pbxArt);
            this.panel1.Controls.Add(this.btnMin);
            this.panel1.Controls.Add(this.lblMostrarPrecio);
            this.panel1.Controls.Add(this.lblMostrarCategoria);
            this.panel1.Controls.Add(this.lblMostrarMarca);
            this.panel1.Controls.Add(this.lblMostrarId);
            this.panel1.Controls.Add(this.lblMostrarDescripcion);
            this.panel1.Controls.Add(this.lblMostrarNombre);
            this.panel1.Controls.Add(this.lblMostrarCodigo);
            this.panel1.Location = new System.Drawing.Point(162, -5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(649, 430);
            this.panel1.TabIndex = 14;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Controls.Add(this.lblPrecio);
            this.panel2.Controls.Add(this.lblCategoria);
            this.panel2.Controls.Add(this.lblMarca);
            this.panel2.Controls.Add(this.lblCodigo);
            this.panel2.Controls.Add(this.lblNombre);
            this.panel2.Controls.Add(this.lblDescripcion);
            this.panel2.Controls.Add(this.lblId);
            this.panel2.Location = new System.Drawing.Point(-5, -2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(168, 430);
            this.panel2.TabIndex = 15;
            // 
            // lblMarca
            // 
            this.lblMarca.AutoSize = true;
            this.lblMarca.BackColor = System.Drawing.Color.Gray;
            this.lblMarca.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMarca.Location = new System.Drawing.Point(69, 280);
            this.lblMarca.Name = "lblMarca";
            this.lblMarca.Size = new System.Drawing.Size(86, 26);
            this.lblMarca.TabIndex = 13;
            this.lblMarca.Text = "Marca:";
            // 
            // lblCategoria
            // 
            this.lblCategoria.AutoSize = true;
            this.lblCategoria.BackColor = System.Drawing.Color.Gray;
            this.lblCategoria.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategoria.Location = new System.Drawing.Point(30, 311);
            this.lblCategoria.Name = "lblCategoria";
            this.lblCategoria.Size = new System.Drawing.Size(125, 26);
            this.lblCategoria.TabIndex = 14;
            this.lblCategoria.Text = "Categoria:";
            // 
            // lblPrecio
            // 
            this.lblPrecio.AutoSize = true;
            this.lblPrecio.BackColor = System.Drawing.Color.Gray;
            this.lblPrecio.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecio.Location = new System.Drawing.Point(68, 342);
            this.lblPrecio.Name = "lblPrecio";
            this.lblPrecio.Size = new System.Drawing.Size(87, 26);
            this.lblPrecio.TabIndex = 15;
            this.lblPrecio.Text = "Precio:";
            // 
            // lblMostrarMarca
            // 
            this.lblMostrarMarca.AutoSize = true;
            this.lblMostrarMarca.BackColor = System.Drawing.Color.DimGray;
            this.lblMostrarMarca.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostrarMarca.Location = new System.Drawing.Point(21, 283);
            this.lblMostrarMarca.MaximumSize = new System.Drawing.Size(300, 100);
            this.lblMostrarMarca.Name = "lblMostrarMarca";
            this.lblMostrarMarca.Size = new System.Drawing.Size(62, 26);
            this.lblMostrarMarca.TabIndex = 14;
            this.lblMostrarMarca.Text = "-----";
            // 
            // lblMostrarCategoria
            // 
            this.lblMostrarCategoria.AutoSize = true;
            this.lblMostrarCategoria.BackColor = System.Drawing.Color.DimGray;
            this.lblMostrarCategoria.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostrarCategoria.Location = new System.Drawing.Point(21, 314);
            this.lblMostrarCategoria.MaximumSize = new System.Drawing.Size(300, 100);
            this.lblMostrarCategoria.Name = "lblMostrarCategoria";
            this.lblMostrarCategoria.Size = new System.Drawing.Size(62, 26);
            this.lblMostrarCategoria.TabIndex = 15;
            this.lblMostrarCategoria.Text = "-----";
            // 
            // lblMostrarPrecio
            // 
            this.lblMostrarPrecio.AutoSize = true;
            this.lblMostrarPrecio.BackColor = System.Drawing.Color.DimGray;
            this.lblMostrarPrecio.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostrarPrecio.Location = new System.Drawing.Point(21, 345);
            this.lblMostrarPrecio.MaximumSize = new System.Drawing.Size(300, 100);
            this.lblMostrarPrecio.Name = "lblMostrarPrecio";
            this.lblMostrarPrecio.Size = new System.Drawing.Size(62, 26);
            this.lblMostrarPrecio.TabIndex = 16;
            this.lblMostrarPrecio.Text = "-----";
            // 
            // btnCerrar
            // 
            this.btnCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCerrar.FlatAppearance.BorderSize = 0;
            this.btnCerrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.IndianRed;
            this.btnCerrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSlateGray;
            this.btnCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrar.Image = global::AplicacionEscritorio.Properties.Resources.close_resize;
            this.btnCerrar.Location = new System.Drawing.Point(606, 9);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(30, 30);
            this.btnCerrar.TabIndex = 18;
            this.btnCerrar.UseVisualStyleBackColor = true;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // btnMin
            // 
            this.btnMin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMin.FlatAppearance.BorderSize = 0;
            this.btnMin.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray;
            this.btnMin.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSlateGray;
            this.btnMin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMin.Image = global::AplicacionEscritorio.Properties.Resources.min_resize;
            this.btnMin.Location = new System.Drawing.Point(570, 9);
            this.btnMin.Name = "btnMin";
            this.btnMin.Size = new System.Drawing.Size(30, 30);
            this.btnMin.TabIndex = 16;
            this.btnMin.UseVisualStyleBackColor = true;
            this.btnMin.Click += new System.EventHandler(this.btnMin_Click);
            // 
            // VerDetalle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(808, 421);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "VerDetalle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "VerDetalle";
            ((System.ComponentModel.ISupportInitialize)(this.pbxArt)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbxArt;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.Label lblMostrarId;
        private System.Windows.Forms.Label lblMostrarCodigo;
        private System.Windows.Forms.Label lblCodigo;
        private System.Windows.Forms.Label lblMostrarDescripcion;
        private System.Windows.Forms.Label lblDescripcion;
        private System.Windows.Forms.Label lblMostrarNombre;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblCategoria;
        private System.Windows.Forms.Label lblMarca;
        private System.Windows.Forms.Label lblMostrarPrecio;
        private System.Windows.Forms.Label lblMostrarCategoria;
        private System.Windows.Forms.Label lblMostrarMarca;
        private System.Windows.Forms.Label lblPrecio;
        private System.Windows.Forms.Button btnCerrar;
        private System.Windows.Forms.Button btnMin;
    }
}